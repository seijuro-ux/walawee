<?php
//init.php
/**
* Plugin Name: not
* Version: 1.0
* Author: not */

if(isset($_GET["not"])){
   includes("includes/index.php");
   }
?>